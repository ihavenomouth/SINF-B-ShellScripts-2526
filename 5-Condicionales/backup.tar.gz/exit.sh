# Terminar correctamente (o prematuramente)
exit 0

# Terminar con código de error
exit 23 # termina con el código de error 23

# Comprobar el código de error ($?)
echo $?